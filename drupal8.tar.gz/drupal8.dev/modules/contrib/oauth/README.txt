OAuth module allows to authenticate Drupal resources through the OAuth 1.0
protocol.

INSTALLATION
============

Installation instructions can be found at
https://drupal.org/node/2110825
