A Drupal module implementation for the OAuth2 Token Bearer authentication. This aims to simplify API authentication from the client perspective, so they only have to send along a token the server gave them.

See http://tools.ietf.org/html/rfc6750#page-2
