# rest_books

This is a API that has a book content type and serves it using a rest export [api/v1/books]
and also has permissions to do all the REST methods in it's drupal URLs
